<!--- © 2020 and later: Unicode, Inc. and others. ---> 
<!--- License & terms of use: http://www.unicode.org/copyright.html#License --->

# Configuring VS Code for ICU4C

  - create `.vscode` folder in icu4c/source
  - Copy `tasks.json` and `launch.json` files into `.vscode` folder

NOTE
 Before you build `icu4c` from vs code. run [`./runConfigureICU` command first](http://userguide.icu-project.org/icufaq).
